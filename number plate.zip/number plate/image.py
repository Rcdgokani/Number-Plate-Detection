import cv2
import pytesseract

# Load an image from file (replace 'your_image.jpg' with the actual path to your image)
image_path = 'C:/Users/devar/Downloads/Car-Number-Plates-Detection-main/Car-Number-Plates-Detection-main/plates/scaned_img_7.jpg'
image = cv2.imread(image_path)

# Check if the image was loaded successfully
if image is None:
    print(f"Failed to load image from {'C:/Users/devar/Downloads/Car-Number-Plates-Detection-main/Car-Number-Plates-Detection-main/plates/abcd'}")
else:
    # Convert the image to grayscale (optional, but can improve OCR accuracy)
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Perform OCR using pytesseract
    text = pytesseract.image_to_string(gray_image)

    # Print the extracted text
    print("Extracted Text:")
    print(text)
