
import cv2
import pytesseract
import csv

# Path to the Haar Cascade XML file for plate detection
harcascade = "C:/Users/devar/Downloads/Car-Number-Plates-Detection-main/Car-Number-Plates-Detection-main/model/haarcascade_russian_plate_number.xml"

# Path to the Tesseract executable (replace with your actual path)
pytesseract.pytesseract.tesseract_cmd = r'C:/Program Files/Tesseract-OCR/tesseract.exe'

# Initialize the video capture object
cap = cv2.VideoCapture(0)

# Set the camera frame width and height
cap.set(3, 640)
cap.set(4, 480)

# Minimum area for detected plates
min_area = 500

# Create a set to store unique recognized plate text
unique_plate_texts = set()

# Create a CSV file if it doesn't exist .0.0.0.00.or open it in append mode
csv_file = open('plates.csv', 'a', newline='', encoding='utf-8')
csv_writer = csv.writer(csv_file)

# Check if the CSV file is empty; if so, write the header
if csv_file.tell() == 0:
    csv_writer.writerow(['Plate Text'])

while True:
    success, img = cap.read()

    # Load the Haar Cascade classifier
    plate_cascade = cv2.CascadeClassifier(harcascade)
    img_gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    # Detect plates in the grayscale frame with adjusted parameters
    plates = plate_cascade.detectMultiScale(img_gray, scaleFactor=1.2, minNeighbors=5, minSize=(30, 30))

    for (x, y, w, h) in plates:
        area = w * h

        if area > min_area:
            # Extract the plate region
            img_roi = img[y:y + h, x:x + w]

            # Convert the plate region to grayscale for better OCR results
            img_roi_gray = cv2.cvtColor(img_roi, cv2.COLOR_BGR2GRAY)

            # Threshold the plate region to enhance text visibility
            _, img_roi_thresh = cv2.threshold(img_roi_gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

            # Perform OCR using Tesseract on the thresholded image
            plate_text = pytesseract.image_to_string(img_roi_thresh, config='--psm 7')

            # Check if the plate text is unique before saving
            if plate_text and plate_text not in unique_plate_texts:
                unique_plate_texts.add(plate_text)

                # Display the recognized text on the image
                cv2.putText(img, plate_text, (x, y - 5), cv2.FONT_HERSHEY_COMPLEX_SMALL, 1, (255, 0, 255), 2)

                # Save the recognized text to the CSV file
                csv_writer.writerow([plate_text])

    # Show the processed frame
    cv2.imshow("Result", img)

    # Exit the program when the 'Esc' key is pressed
    if cv2.waitKey(1) & 0xFF == 27:
        break

# Release the video capture object, close the CSV file, and close all OpenCV windows
cap.release()
csv_file.close()
cv2.destroyAllWindows()
